<?php
return
array(
    '1' => 'Data',
    '2' => 'Teacher',
    '3' => 'Course',
    '4' => 'Bbs',
    '5' => '服务',
);
