<?php
return [
    1  => 'PHP',
    2  => 'Vue',
    3  => 'Mysql',
    4  => 'Reids',
    5  => 'Javascirpt',
    6  => 'Nginx',
    7  => 'Apache',
    8  => 'Docker',
    9  => 'Linux',
    10 => 'Html5',
];
