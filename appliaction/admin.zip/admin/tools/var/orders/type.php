<?php
return
array(
    '1' => '汽车交易',
    '2' => '服务交易',
);
