<?php
return
array(
    'index' => array(
        'login' => array('index'),
    ),
);
