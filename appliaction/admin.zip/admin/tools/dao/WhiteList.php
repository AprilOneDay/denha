<?php
namespace app\admin\tools\dao;

class WhiteList
{

}
