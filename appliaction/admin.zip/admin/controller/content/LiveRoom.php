<?php
/**
 * 直播课程
 */
namespace app\admin\controller\content;

use app\app\controller;

class LiveRoom extends \app\admin\controller\Init
{
    public function lists()
    {
        $this->show();
    }

    public function edit()
    {
        $this->show();
    }
}
